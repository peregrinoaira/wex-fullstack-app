﻿namespace wex_fs_22_team_2_be.Models
{
    public class ShopKeepDataTransport
    {
        public Product Product { get; set; }
        public Boolean IsShopKeeper { get; set; }
    }
}
