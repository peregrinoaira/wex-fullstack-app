﻿namespace wex_fs_22_team_2_be.Models
{
    public class Report
    {
        public int? Id { get; set; }
        public int ProductId { get; set; }
    }
}
