﻿namespace wex_fs_22_team_2_be.Models
{
    public class Sale
    {
        public int? Id { get; set; }
        public float SalesPrice { get; set; }
        public DateTime SalesStart { get; set; }
        public DateTime SalesEnd { get; set; }
    }
}

