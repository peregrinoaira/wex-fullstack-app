﻿namespace wex_fs_22_team_2_be.Models
{
    public class ProductCategory
    {
        public int? Id { get; set; }
        public string CategoryName { get; set; }
    }
}
