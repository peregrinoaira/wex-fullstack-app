import { Component, OnInit } from '@angular/core';
import { Product } from 'app/Product';
import { ProductsService } from 'app/services/products.service';
import { CategoryService } from 'app/services/category.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ShopKeepProduct } from 'app/ShopKeepProduct';
import { ProductCategory } from 'app/ProductCategory';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-shopkeep',
  templateUrl: './shopkeep.component.html',
  styleUrls: ['./shopkeep.component.css']
})
export class ShopkeepComponent implements OnInit {
  products: ShopKeepProduct[]=[];
  getBaseUrl = 'https://localhost:7154/api/Product';
  editObject: ShopKeepProduct = {
    productName: '',
    productDescription: '',
    productImage: '',
    productPrice: 0,
    minimumPrice: 0,
    discontinued: false,
    discontinuedDate: undefined,
    onSale: false,
    onSaleId: undefined,
    coupon: false,
    couponId: undefined,
    productCategoryId: 0,
    totalInventoryCount: 0,
  }
  
  constructor(
    private productService: ProductsService,
    private http: HttpClient,
    private categoryService: CategoryService
    ) {}
  
  ngOnInit(): void {
    this.getShopKeepProducts();
    this.categoryService.whenListOfCategoriesChanges().subscribe(catArr => this.categories = catArr)
    this.categoryService.getAllCategories()
  }
   
  getShopKeepProducts(): void{
    this.http.get<ShopKeepProduct[]>(`${this.getBaseUrl}/shopkeep-products`).subscribe(products => this.products = products)
  }
// functions for product crud
  handleAddProduct():void {
 
  }

  handleEditProduct():void {
  
  }

  handleDeleteProduct():void {
  
  }

  handleCancelProductEdit():void{

  }

  handleSubmitProductEdit():void{
   
  }

  //category stuff ----------------------------------------------------
  categories: ProductCategory[] = [];
  newCategoryName: string = '';
  toggle?: number;
  changesToCategory: string = '';

  handleAddCategory(category: string):void {
    console.log("added")
    const newCategoryObject: ProductCategory = {categoryName: category}
    this.categoryService.addCategory(newCategoryObject).subscribe(() => this.categoryService.getAllCategories()) 
    this.newCategoryName = '';   
  }

  handleEditCategory(id: number | undefined):void {
    console.log("edited", id)
    this.toggle = id;
  }

  handleDeleteCategory(id: number | undefined):void {
    console.log("deleted", id)
    this.categoryService.deleteCategory(id).subscribe(()=> this.categoryService.getAllCategories())
  }

  handleCancelEdit():void{
    this.toggle = undefined;
  }

  handleSubmitEdit(_category: string, _categoryId: number | undefined):void{
    const category: ProductCategory = {
      id: _categoryId,
      categoryName: _category
    }
    this.categoryService.updateCategory(category).subscribe(()=> this.categoryService.getAllCategories())
    this.toggle = undefined;
    this.changesToCategory = ''
  }

















} 