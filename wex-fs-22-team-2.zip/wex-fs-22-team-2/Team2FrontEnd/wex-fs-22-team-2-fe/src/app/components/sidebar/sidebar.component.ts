import { Component, OnInit } from '@angular/core';
import { ProductCategory } from 'app/ProductCategory';
import { User } from 'app/User';
import { Coupon } from 'app/Coupon'
import { ProductsService } from 'app/services/products.service';
import { Product } from 'app/Product';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  categories: ProductCategory[] = [{id:1, categoryName:"string"}]
  users: User[] = [{id:1, username:"User1", email:"Email1", password:"pw1", isAdmin:false, isShopKeeper:false, isCustomer:true, token:1}]
  coupons: Coupon[] = [{id:1, ammountDiscounted:10, couponStart:new Date, couponEnd:new Date}]
  products:Product[]=[];

  constructor(private productService:ProductsService) { }

  ngOnInit(): void {
    this.getAllProduct();
  }

  onAddUser(): void {
    alert("Add User")
  }

  onSearchUser(): void {
    alert("Search for Users")
  }

  onAddProduct(): void {
    alert("Add Product")
  }

  onAddCoupon(): void {
    alert("Add Coupon")
  }

  filterByCouponName(ev:any): void {
    const searchValue = ev.target.value
    console.log(ev.target.value)
  }

  filterByProductCategory(ev: any): void {
    console.log(ev.target.value)
  }

  filterByProductName(ev: any): void {
    const searchValue = ev.target.value
    console.log(ev.target.value)
  }
  
  onAddProductCategory(): void {
    alert("Add Product Category")
  }

  onAddProductToCart(): void {
    alert("Add Product to Cart")
  }

  onCheckout(): void {
    alert("Checkout")
  }

  onClearCart(): void {
    alert("Clear Cart")
  }

  onSubmitOrder(): void {
    alert("Submit Order")
  }

  onBackToCart(): void {
    alert("Back to Cart")
  }


  getAllProduct(){
   this.productService.getProducts().subscribe(res=>{
    console.log(res);
    this.products=res;
    console.log(this.products)
    })
  }

}