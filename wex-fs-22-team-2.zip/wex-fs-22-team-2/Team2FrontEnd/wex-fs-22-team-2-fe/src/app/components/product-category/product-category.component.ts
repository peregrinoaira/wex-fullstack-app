import { Component, OnInit } from '@angular/core';
import { ProductCategory } from 'app/ProductCategory';
import { CategoryService } from 'app/services/category.service';

@Component({
  selector: 'app-product-category',
  templateUrl: './product-category.component.html',
  styleUrls: ['./product-category.component.css']
})
export class ProductCategoryComponent implements OnInit {
  categories: ProductCategory[] = [];
  newCategoryName: string = '';
  toggle?: number;
  changesToCategory: string = '';
 
  constructor(private categoryService: CategoryService) {}

  ngOnInit(): void {
    this.categoryService.whenListOfCategoriesChanges().subscribe(catArr => this.categories = catArr)
    this.categoryService.getAllCategories()
  }

  handleAddCategory(category: string):void {
    console.log("added")
    const newCategoryObject: ProductCategory = {categoryName: category}
    this.categoryService.addCategory(newCategoryObject).subscribe(() => this.categoryService.getAllCategories()) 
    this.newCategoryName = '';   
  }

  handleEditCategory(id: number | undefined):void {
    console.log("edited", id)
    this.toggle = id;
  }

  handleDeleteCategory(id: number | undefined):void {
    console.log("deleted", id)
    this.categoryService.deleteCategory(id).subscribe(()=> this.categoryService.getAllCategories())
  }

  handleCancelEdit():void{
    this.toggle = undefined;
  }

  handleSubmitEdit(_category: string, _categoryId: number | undefined):void{
    const category: ProductCategory = {
      id: _categoryId,
      categoryName: _category
    }
    this.categoryService.updateCategory(category).subscribe(()=> this.categoryService.getAllCategories())
    this.toggle = undefined;
    this.changesToCategory = ''
  }
}