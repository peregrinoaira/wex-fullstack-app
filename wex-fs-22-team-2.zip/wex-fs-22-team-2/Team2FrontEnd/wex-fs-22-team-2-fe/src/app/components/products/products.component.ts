import { Component, OnInit } from '@angular/core';
import { Product } from 'app/Product';
import { ProductsService } from 'app/services/products.service';
import { UiService } from 'app/services/ui.service';
import { User } from 'app/User';
import { OrderDetail } from 'app/OrderDetail';
import { OrdersService } from 'app/services/orders.service';
import { CategoryService } from 'app/services/category.service';
import { ProductCategory } from 'app/ProductCategory';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit {
  //this is a local variable which is being overidden in the ngOnIt() subscribeToUserChange()
  currentUser: User = {
    id: 0,
    username: 'Guest',
    email: 'Unknown',
    password: '',
    isAdmin: false,
    isShopKeeper: false,
    isCustomer: true,
    token: 0
  }
  //this is a local variable which is being overidden in the ngOnIt() getProducts()
  products: Product[] = [];
  categories: ProductCategory[] = []
  seeCart: boolean = false;
  constructor(private productsService: ProductsService, private uiService: UiService, private ordersService: OrdersService, private categoryService: CategoryService) { }

  //will have to subscribe to the categories get all function in the categories services 
  ngOnInit(): void {
    this.uiService.subscribeToUserChanges().subscribe(user => this.currentUser = user);
    this.productsService.getProducts().subscribe(prods => this.products = prods);
    setTimeout(() =>     console.log(this.products), 5000);
    this.categoryService.whenListOfCategoriesChanges().subscribe(cat => this.categories = cat);
    this.categoryService.getAllCategories()
  }

  filterByProductName(ev: any): void {
    const searchValue = ev.target.value
    console.log(ev.target.value)
  }

  filterByProductCategory(ev: any): void {
    console.log(ev.target.value.id)
  }

  //This is the array of cartItems to be added to the cart locally.
  itemsInCart: OrderDetail[] = [];

  //this takes in a product id and quantity and builds the order array
  handleAddToCart(inCartItem: any):void {
  const product = inCartItem.singleProduct;
  //take the price of the product and multiply it by the quantity: final product price
  const finalProductPrice = product.productPrice * inCartItem.quantity;
  //builds an object which is a orderDetail
  const _orderDetail = {
    productId: product.id,
    productName: product.productName,
    productDescription: product.productDescription,
    productImage: product.productDescription,
    productPrice: product.productPrice,
    quantity: inCartItem.quantity,
    totalPriceForProduct: finalProductPrice
  }
  //add orderdetails to the itemsInCart Array
  this.itemsInCart.push(_orderDetail);
  console.log(this.itemsInCart)
  this.ordersService.addOrderDetailLocally(this.itemsInCart)
  }
}