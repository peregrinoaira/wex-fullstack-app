import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-coupon',
  templateUrl: './edit-coupon.component.html',
  styleUrls: ['./edit-coupon.component.css']
})
export class EditCouponComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
