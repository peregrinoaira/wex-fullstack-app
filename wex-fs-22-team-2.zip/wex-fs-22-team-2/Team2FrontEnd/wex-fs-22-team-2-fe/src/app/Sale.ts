export interface Sale {
    id?: number;
    salePrice: number;
    saleStart: Date;
    SaleEnd: Date;
}