import { OrderDetail } from "./OrderDetail";

export interface OrderPacket {
    orderDetails: OrderDetail[];
    userId: number;
    orderTotal: number;
}