export interface Inventory  {
    id?: number;
    productId: number; //passed with what product
    priceIn: number;
    shipmentQuantity: number;
    currentQuantity: number;
    dateIn: Date;
}