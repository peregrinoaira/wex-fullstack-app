export interface ShopKeepProduct {
    id?: number;
    productName: string;
    productDescription: string;
    productImage: string;
    productPrice: number;
    minimumPrice: number;
    discontinued: boolean;
    discontinuedDate?: Date;
    onSale: boolean;
    onSaleId?: number; //from the sale table in backend
    coupon: boolean;
    couponId?: string;
    productCategoryId: number; //from the product categories backend
    totalInventoryCount: number;
}