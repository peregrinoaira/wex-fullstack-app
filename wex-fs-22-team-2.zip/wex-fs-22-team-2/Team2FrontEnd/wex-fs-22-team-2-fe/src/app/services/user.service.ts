import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject, map } from 'rxjs';
import { User } from 'app/User';
import { UserCreateDataTransport } from 'app/UserCreateDataTransport';
import { UiService } from './ui.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
}

@Injectable({
  providedIn: 'root'
})

export class UserService {
  private apiUrl = 'https://localhost:7154/api/User';

  constructor(private http: HttpClient) { }

  //Get all cards
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.apiUrl)
  }

  loginWithUsernameAndPassword(username: string, password: string): Observable<User | undefined> {
    return this.http
      .patch<User>(`${this.apiUrl}/Login/${username}/${password}`, '');
  }

  logoutWithId(currentUser: User): Observable<Object> {
    return this.http
      .patch(`${this.apiUrl}/Logout/${currentUser.id}`,'', httpOptions);
  }

  postNewUser(newUser: User, isAdmin: boolean): Observable<User | undefined> {
    return this.http
      .post<User>(`${this.apiUrl}`, newUser, httpOptions);
  }

  updateExistingUser(obj: UserCreateDataTransport): Observable<User | undefined> {
    return this.http
      .put<User>(`${this.apiUrl}/${obj.userToCreate.id}`, obj);
  }

  deleteExistingUser(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}