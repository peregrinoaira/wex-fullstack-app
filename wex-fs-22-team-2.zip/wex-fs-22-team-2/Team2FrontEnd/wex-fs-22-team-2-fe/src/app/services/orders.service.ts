import { Injectable } from '@angular/core';
import { OrderDetail } from 'app/OrderDetail';
import { Observable, Subject, ReplaySubject } from 'rxjs';
import { User } from 'app/User';
import { UiService } from './ui.service';
import { UserService } from './user.service';
import { OrderPacket } from 'app/OrderPacket';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OrderHistory } from 'app/OrderHistory';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  //local variable
  localInCartArr: any = []
  //subject
  localInCartSubject: ReplaySubject<any> = new ReplaySubject();
  //subject function
  whenLocalInCartSubjectChanges(): Observable<any> {
    return this.localInCartSubject.asObservable()
  }

  currentUser: User = {
    id: 0,
    username: 'Guest',
    email: 'Unknown',
    password: '',
    isAdmin: false,
    isShopKeeper: false,
    isCustomer: true,
    token: 0
  }

  orderPacket: OrderPacket = {orderDetails: [], userId: 0, orderTotal: 0}

  constructor(private uiService: UiService, private http: HttpClient) { 
    this.uiService.subscribeToUserChanges().subscribe(user => this.currentUser = user);
  }

  addOrderDetailLocally(cartArr: any) {
    this.localInCartArr = [];
    this.localInCartArr = cartArr;
    this.localInCartSubject.next(cartArr)
    console.log(this.localInCartArr)
  }

  attemptSubmitOrder(order: OrderDetail[]): void {
    this.orderPacket.orderDetails = order;
    if (this.currentUser.id === undefined) {
      this.orderPacket.userId = 0;
    }
    else {
      this.orderPacket.userId = this.currentUser.id;
    }
    order.forEach(e => this.orderPacket.orderTotal += e.totalPriceForProduct);
    console.log(JSON.stringify(this.orderPacket));
    this.http.patch('https://localhost:7154/api/Order/CheckoutPassingDetails', this.orderPacket).subscribe(
      res => console.log("result" + res), err => console.log("error" + err));
  }


  getAllOrders(id: number): Observable<OrderHistory[] | undefined> {
    return this.http.get<OrderHistory[]>(`https://localhost:7154/api/Order/GetUserOrderHistory/${id}`);
  }

}
