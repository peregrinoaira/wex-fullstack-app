import { Injectable } from '@angular/core';
import { Observable, Subject, Observer } from 'rxjs';
import { User } from 'app/User';
import { UserService } from './user.service';
import { ObserversModule } from '@angular/cdk/observers';
import { Router } from '@angular/router';
import { ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UiService {
  //variables
  readonly defaultUser: User = {
    id: 0,
    username: 'Guest',
    email: 'Unknown',
    password: '',
    isAdmin: false,
    isShopKeeper: false,
    isCustomer: true,
    token: 0
  }
  currentMessage: string | undefined;
  users: User[] = []

  //subjects
  currentUserSubject: ReplaySubject<User> = new ReplaySubject();
  currentMessageSubject: Subject<string | undefined> = new Subject();
  listOfUsersSubject: Subject<User[]> = new Subject();
  
  //subscribe functions
  whenListOfUsersSubjectChanges(): Observable<User[] | undefined> {
    return this.listOfUsersSubject.asObservable()
  }
  subscribeToUserChanges(): Observable<User> {
    return this.currentUserSubject.asObservable();
  }
  
  //CONSTRUCTOR
  constructor(private userService: UserService, private router: Router) { }

  //ui-service attempt to get all users
  attemptGetUsers(): void{
    this.userService.getAllUsers().subscribe(usersArr => {
      this.users = usersArr
      this.listOfUsersSubject.next(usersArr)
    })
  }

  //ui-service attempt to login calling user service
  attemptLogin(credentials: {username: string, password: string}): void {
    const currentUser: User = {...this.defaultUser};
    this.userService.loginWithUsernameAndPassword(credentials.username, credentials.password)
      .subscribe(possibleUser => {
        if (possibleUser !== undefined) {
          currentUser.id = possibleUser.id;
          currentUser.username = possibleUser.username;
          currentUser.password = possibleUser.password;
          currentUser.isAdmin = possibleUser.isAdmin;
          currentUser.isShopKeeper = possibleUser.isShopKeeper;
          currentUser.isCustomer = possibleUser.isCustomer;
          currentUser.token = possibleUser.token;
          this.currentUserSubject.next(currentUser);
          if (currentUser.isCustomer) this.router.navigate(['/products']);
          if (currentUser.isAdmin) this.router.navigate(['/edit-user']);
          if (currentUser.isShopKeeper) this.router.navigate(['/product']);
        }
        else {
          alert(`Either username ${credentials.username} was not found or your password was wrong.\nPlease check your spelling or register for a new account.`);
        }
      }, () => alert(`Database not available.\nPlease try again later.`));
  }

  //ui-service attempt to logout calling user service
  attemptLogout(currentUser: User): void {
    this.userService.logoutWithId(currentUser)
      .subscribe(res => {
        if (res === 'logout worked') {
          this.currentUserSubject.next(this.defaultUser);
          this.router.navigate(['/products']);
        }
        else {
          alert("Logout failed.");
        }
      });
  }

  //ui-service attempt to register calling user service
  attemptRegister(credentials: {username: string, password: string, email: string}): void {
    const newUser: User = {
      username: credentials.username, 
      email: credentials.email,
      password: credentials.password,
      isAdmin: false,
      isShopKeeper: false,
      isCustomer: true,
      token: 0
    }
    const currentUser: User = {...this.defaultUser};
    this.userService.postNewUser(newUser, newUser.isAdmin)
      .subscribe(possibleNewUser => {
        if (possibleNewUser !== undefined) {
          currentUser.id = possibleNewUser.id;
          currentUser.username = possibleNewUser.username;
          currentUser.password = possibleNewUser.password;
          currentUser.isAdmin = possibleNewUser.isAdmin;
          currentUser.isShopKeeper = possibleNewUser.isShopKeeper;
          currentUser.isCustomer = possibleNewUser.isCustomer;
          currentUser.token = possibleNewUser.token;
          this.currentUserSubject.next(currentUser);
          if (currentUser.isCustomer) this.router.navigate(['/products']);
        }
        else {
          alert(`Unable to register ${credentials.username}.\nPlease try again.`);
        }
      }, () => alert(`Database not available.\nPlease try again later.`));
  }

}
