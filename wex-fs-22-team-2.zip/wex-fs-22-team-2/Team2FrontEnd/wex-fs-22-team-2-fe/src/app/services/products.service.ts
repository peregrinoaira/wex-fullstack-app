import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from 'app/Product';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
baseUrl='https://localhost:7154/api/Product'

  constructor(private http:HttpClient) { }

  //get products
  getProducts():Observable<Product[]>{
    return this.http.get<Product[]>(this.baseUrl)
  }
  
  //get one product
  getProduct(id:string):Observable<Product> {
  return this.http.get<Product>(this.baseUrl + '/' + id)
  }

  //Add product
  AddProduct(products:Product):Observable<Product>{
    return this.http.post<Product>(this.baseUrl,products)
  }

  //Delete a product
  deleteProduct(id:string):Observable<Product>{
    return this.http.delete<Product>(this.baseUrl + '/' + id)
  }

  //Update a product
  updateProduct(products:Product):Observable<Product>{
    return this.http.put<Product>(this.baseUrl + '/' + products.id,products)
  }
}
