import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { ProductCategory } from 'app/ProductCategory';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private baseUrl: string = "https://localhost:7154/api/ProductCategory"
  //subjects
  listOfCategoriesSubject: Subject<ProductCategory[]> = new Subject();
  //subject functions
  whenListOfCategoriesChanges(): Observable<ProductCategory[]>{
    return this.listOfCategoriesSubject.asObservable();
  }
  
  constructor(private http: HttpClient) {}

   //get products
   getAllCategories():void{
    this.http.get<ProductCategory[]>(this.baseUrl).subscribe(categories => {
      this.listOfCategoriesSubject.next(categories)
    })
  }

  // Get a category by id.
  getCategory(id: number): Observable<ProductCategory> {
    return this.http.get<ProductCategory>(this.baseUrl + '/' + id)
  }

  // Add a category.
  addCategory(category: ProductCategory): Observable<any> {
    return this.http.post(this.baseUrl, category)
  }

  // Update a category by id.
  updateCategory(category: ProductCategory): Observable<ProductCategory> {
    return this.http.put<ProductCategory>(this.baseUrl + '/', category)
  }

  // Delete a category by id.
  deleteCategory(id: number | undefined): Observable<any>{
    return this.http.delete(`${this.baseUrl}/${id}`)
  }
}