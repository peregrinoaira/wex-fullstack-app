export interface OrderDetail {
    id?: number;
    productId: number;
    productName: string;
    productDescription: string;
    productImage: string;
    productPrice: number;
    quantity: number;
    totalPriceForProduct: number;
}