export interface Product {
    id?: number;
    productName: string;
    productDescription: string;
    productImage: string;
    productPrice: number;
    minimumPrice: number;
    discontinued: boolean;
    onSaleId: number; //from the sale table in backend
    productCategoryId: number; //from the product categories backend
}