import { User } from "./User"

export interface UserCreateDataTransport {
    isAdmin: boolean,
    localuserid: number,
    userToCreate: User
}