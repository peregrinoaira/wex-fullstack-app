export interface Order {
    id?: number;
    orderIdNum: string;
    userId: number; //pulled for the user that is saved in state
    orderTotal: number;
}
