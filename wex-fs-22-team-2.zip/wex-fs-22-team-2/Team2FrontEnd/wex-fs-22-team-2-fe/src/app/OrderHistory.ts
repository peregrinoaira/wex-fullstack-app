import { OrderDetail } from "./OrderDetail";

export interface OrderHistory {
    orderDetailsList: OrderDetail[];
    orderNumId: string;
    orderTotal: number;
}