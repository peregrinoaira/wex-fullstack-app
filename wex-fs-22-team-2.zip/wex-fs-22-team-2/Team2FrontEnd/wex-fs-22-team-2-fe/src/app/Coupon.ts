export interface Coupon {
    id?: number;
    ammountDiscounted: number;
    couponStart: Date;
    couponEnd: Date;
}
